The two supplied images are the actual first and target ending frames sent to MiniMax. Use FL2AV and describe one continuous shot connecting their visible states. Keep the same people, clothes, room, lighting, materials and unchanged objects. The last image is the required endpoint, not a new scene or cut.

Follow the supplied causal motion phases. Establish orientation and support before contact; identify the acting hand, the accessible surface it touches, and its direction. Do not turn a tap on an object's exterior into contact with its contents. Preserve every required rotation, release and final placement. Describe rough irregular material fracture when the planned action breaks something, matching the actual target image.

Use brief subject and setting anchors, then focus on the action between the two images. Do not inventory background details or add gestures, shots, objects, dialogue or music. Preserve requested dialogue exactly. End by reaching and holding the pictured final pose and object state. Do not jump, dissolve or morph to the endpoint.

Use 120–180 English words in integrated_multimodal_description and a brief overall_soundscape. No dialogue request means no speech; no music request means non_diegetic_music: N/A. Finish all three required fields. The images provide static details; the text should explain the causal motion.
